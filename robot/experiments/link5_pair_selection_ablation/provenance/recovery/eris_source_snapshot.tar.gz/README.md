# Link5 pair-selection ablations

Implementation and executable handoff: [HANDOFF.md](HANDOFF.md).

- `balanced_v0`: earlier 10 long / 10 cross-width / 10 local diagonal proposal.
- `refine_v1`: current mask-transition-focused 16 local / 14 remaining pairs.
- `score.py`: unchanged baseline MAD/median, anchor gating and carry policy; new pair selector only.
- `run_scores.py`: both scores from shared raw tracking/geometry inputs.
- `preview.py`: current masks, identical query positions, two graph previews.

The current handoff additionally lists `COSMOS2.5_0010` as excluded, although its
older counts still say 41 primary videos. `prepare_manifest.py` follows all five
explicit exclusions, yielding 40 primary + 1 additional video. Existing excluded
artifacts are preserved. No production defaults changed.

`prepare_gpu.py` generates full-sequence MegaSAM CVD world pointmaps and raw
CoTracker outputs with the saved explicit frame-zero queries. It rejects source,
mask and query hash mismatches, preserves query IDs, scales queries directly to
the native pointmap grid, and saves unfiltered tracker visibility. Both scorers
read the same input NPZ. No SAM/VLM calls or shape-codebook training are used.

`run_gpu_batch.py` requires one visible H200 and a Slurm allocation. It starts with
one longest-video capacity measurement, then a five-video wave, then runs the
remaining videos with five workers total. Failed capacity waves prevent the
remaining GPU work from launching. GPU memory/utilization, host memory, CPU/I/O
pressure and throughput are saved as JSONL. SIGINT/SIGTERM cancels active process
groups and prevents queued videos and dependent CPU scoring from starting.
`eris_job.sh` runs it in an allocation-local tmux session with an immutable shell
snapshot, durable logs and an exit receipt. Stage all source into a new isolated,
frozen remote workspace before submission; never overwrite a running snapshot.

These new GPU entry points have local contract tests only; they are **not yet
validated on Eris and no full-video scores have been produced**. Remote preflight
and the measured capacity waves must succeed before accepting any results.
