import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pdi_eval.perception.dinov2_reference_boxes import (
    box_from_similarity,
    crop_reference_foreground,
    discover_reference_groups,
    guided_box_from_similarity,
    parse_reference_arguments,
    patch_grid_size,
    xyxy_to_normalized_xywh,
)
from pdi_eval.perception.sam3_dinov2_segment import (
    _active_franka_groups,
    _link5_seed_points,
    _link5_prompt_box,
    _parse_named_text_prompts,
    _select_prompt_result,
    _select_tracking_result,
    _text_prompt_for_target,
    _validate_franka_groups,
)


class ReferenceDiscoveryTests(unittest.TestCase):
    def test_discovers_subdirectories_as_targets(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "target-a").mkdir()
            (root / "target-b").mkdir()
            cv2.imwrite(str(root / "target-a" / "one.png"), np.zeros((8, 8, 3), np.uint8))
            cv2.imwrite(str(root / "target-b" / "two.jpg"), np.zeros((8, 8, 3), np.uint8))
            (root / "ignored.txt").write_text("ignored", encoding="utf-8")

            groups = discover_reference_groups(root)

        self.assertEqual(list(groups), ["target-a", "target-b"])
        self.assertEqual([path.name for path in groups["target-a"]], ["one.png"])

    def test_parses_repeated_named_references(self):
        with tempfile.TemporaryDirectory() as temporary:
            image = Path(temporary) / "reference.png"
            cv2.imwrite(str(image), np.zeros((8, 8, 3), np.uint8))
            groups = parse_reference_arguments([f"part={image}", f"part={image}"])
        self.assertEqual(len(groups["part"]), 2)

    def test_discovers_nested_franka_groups_and_ignores_contact_sheets(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for index in range(1, 8):
                group = root / "by_link" / f"link_{index}"
                group.mkdir(parents=True)
                cv2.imwrite(str(group / "001.png"), np.ones((8, 8, 3), np.uint8))
                cv2.imwrite(
                    str(group / "contact_sheet_15.png"), np.ones((8, 8, 3), np.uint8)
                )

            groups = discover_reference_groups(root)

        self.assertEqual(list(groups), [f"link{index}" for index in range(1, 8)])
        self.assertTrue(all(len(paths) == 1 for paths in groups.values()))

    def test_crops_black_reference_canvas_to_foreground(self):
        pixels = np.zeros((100, 200, 3), dtype=np.uint8)
        pixels[30:70, 80:120] = 180
        cropped = crop_reference_foreground(
            Image.fromarray(pixels), padding_fraction=0.0
        )
        self.assertEqual(cropped.size, (40, 40))


class BoxExtractionTests(unittest.TestCase):
    def test_extracts_and_pads_high_similarity_component(self):
        similarity = np.zeros((10, 20), dtype=np.float32)
        similarity[2:6, 8:13] = 0.9
        box, metrics = box_from_similarity(
            similarity,
            (100, 200),
            top_fraction=0.08,
            padding_fraction=0.1,
        )
        self.assertEqual(box, (75, 16, 135, 64))
        self.assertGreaterEqual(metrics["component_patches"], 20)

    def test_falls_back_to_peak_when_component_minimum_is_unmet(self):
        similarity = np.zeros((4, 4), dtype=np.float32)
        similarity[1, 2] = 1.0
        box, _ = box_from_similarity(
            similarity,
            (40, 40),
            top_fraction=0.01,
            padding_fraction=0.0,
            minimum_component_patches=3,
        )
        self.assertEqual(box, (20, 10, 30, 20))

    def test_box_normalization_matches_sam3_xywh_contract(self):
        normalized = xyxy_to_normalized_xywh((20, 10, 100, 50), (100, 200))
        np.testing.assert_allclose(normalized, (0.1, 0.1, 0.4, 0.4))

    def test_patch_grid_preserves_aspect_and_patch_multiple(self):
        height, width = patch_grid_size((720, 1280), 840, 14)
        self.assertEqual((height % 14, width % 14), (0, 0))
        self.assertLess(abs(width / height - 1280 / 720), 0.03)

    def test_guided_box_stays_compact_around_reference_prior(self):
        similarity = np.zeros((10, 20), dtype=np.float32)
        similarity[5, 12] = 1.0
        similarity[5, 8] = 0.8
        box, _ = guided_box_from_similarity(
            similarity,
            (100, 200),
            (70, 40, 110, 70),
            padding_fraction=0.10,
        )
        self.assertEqual(box, (65, 37, 113, 73))


class Sam3PromptSelectionTests(unittest.TestCase):
    def test_link5_extends_box_right_and_seeds_joint_negative(self):
        self.assertIn(
            "entire white elongated robot arm link",
            _text_prompt_for_target("link5", {}, "visual"),
        )
        self.assertEqual(
            _text_prompt_for_target("link5", {"link5": "override"}, "visual"),
            "override",
        )
        prompt_box = _link5_prompt_box((702, 0, 1113, 183), 1280)
        self.assertEqual(prompt_box, (702, 0, 1195, 183))
        self.assertEqual(_link5_prompt_box((702, 0, 1200, 183), 1280),
                         (702, 0, 1280, 183))
        points, labels, normalized = _link5_seed_points(prompt_box, (720, 1280))
        self.assertEqual(
            points.tolist(),
            [[746, 101], [860, 101], [1126, 64], [756, 51], [732, 104],
             [1180, 121]],
        )
        self.assertEqual(labels, [1, 1, 1, 0, 0, 0])
        self.assertAlmostEqual(normalized[5][0], 1180 / 1280)

    def test_parses_per_link_text_prompts(self):
        prompts = _parse_named_text_prompts(
            ["link4=white oval joint", "link7=white gripper"],
            {"link4", "link7"},
        )
        self.assertEqual(prompts["link4"], "white oval joint")
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            _parse_named_text_prompts(
                ["link7=one", "link7=two"], {"link7"}
            )

    def test_retires_link1_and_requires_active_franka_links(self):
        discovered = {
            f"link{index}": [Path("reference.png")] for index in range(1, 8)
        }
        groups = _active_franka_groups(discovered)
        self.assertNotIn("link1", groups)
        self.assertEqual(tuple(groups), tuple(f"link{index}" for index in range(2, 8)))
        _validate_franka_groups(groups)
        with self.assertRaisesRegex(ValueError, "missing=.*link7"):
            _validate_franka_groups({name: paths for name, paths in groups.items() if name != "link7"})

    def test_selects_precise_mask_with_box_support(self):
        masks = np.zeros((3, 20, 20), dtype=bool)
        masks[0, 0:5, 0:5] = True
        masks[1, 6:14, 6:14] = True
        masks[2, 5:15, 5:15] = True
        object_id, selected, score = _select_prompt_result(
            np.asarray([1, 2, 3]),
            masks,
            np.asarray([0.99, 0.75, 0.60]),
            (5, 5, 15, 15),
        )
        self.assertEqual(object_id, 3)
        np.testing.assert_array_equal(selected, masks[2])
        self.assertEqual(score, 0.60)

    def test_rejects_inconsistent_sam3_candidate_arrays(self):
        with self.assertRaisesRegex(RuntimeError, "inconsistent candidate arrays"):
            _select_prompt_result(
                np.asarray([1, 2]),
                np.zeros((1, 20, 20), dtype=bool),
                np.asarray([0.9, 0.8]),
                (5, 5, 15, 15),
            )

    def test_tracking_prefers_the_current_sam3_identity(self):
        masks = np.zeros((2, 20, 20), dtype=bool)
        previous = np.zeros((20, 20), dtype=bool)
        previous[4:12, 4:12] = True
        masks[0, 5:13, 5:13] = True
        masks[1, 4:12, 4:12] = True
        selected = _select_tracking_result(
            np.asarray([7, 8]), masks, 8, previous
        )
        self.assertIsNotNone(selected)
        object_id, mask = selected
        self.assertEqual(object_id, 8)
        np.testing.assert_array_equal(mask, masks[1])

    def test_tracking_reassociates_a_replaced_identity_by_mask_overlap(self):
        previous = np.zeros((20, 20), dtype=bool)
        previous[4:12, 4:12] = True
        masks = np.zeros((2, 20, 20), dtype=bool)
        masks[0, 5:13, 5:13] = True
        masks[1, 12:18, 12:18] = True
        selected = _select_tracking_result(
            np.asarray([10, 11]), masks, 7, previous
        )
        self.assertIsNotNone(selected)
        object_id, mask = selected
        self.assertEqual(object_id, 10)
        np.testing.assert_array_equal(mask, masks[0])

    def test_tracking_rejects_an_unrelated_replacement(self):
        previous = np.zeros((100, 100), dtype=bool)
        previous[5:15, 5:15] = True
        replacement = np.zeros((1, 100, 100), dtype=bool)
        replacement[0, 40:90, 40:90] = True
        selected = _select_tracking_result(
            np.asarray([10]), replacement, 7, previous
        )
        self.assertIsNone(selected)


if __name__ == "__main__":
    unittest.main()
