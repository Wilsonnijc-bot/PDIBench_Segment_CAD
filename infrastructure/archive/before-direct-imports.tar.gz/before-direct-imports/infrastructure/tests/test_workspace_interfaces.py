import csv
import json
from pathlib import Path
import subprocess
import sys

import pytest

from pdibench.analysis import analyze, auroc
from pdibench.layout import root, manifest


def write_csv(path, rows):
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def test_analysis_reports_missing_and_moderate_without_imputation(tmp_path):
    scores,labels=tmp_path/'scores.csv',tmp_path/'labels.csv'
    write_csv(scores,[{'case':'a','score':2},{'case':'b','score':1},{'case':'c','score':9},{'case':'d','score':''}])
    write_csv(labels,[{'case':'a','label':1},{'case':'b','label':0},{'case':'c','label':0.5},{'case':'d','label':1},{'case':'e','label':0}])
    report=analyze(scores,labels)
    assert report['auroc']==1 and report['positive_count']==report['negative_count']==1
    assert report['excluded_counts']=={'nonbinary_label':1,'unavailable_value':1,'missing_score':1}
    assert analyze(scores,labels,lower_is_anomalous=True)['auroc']==0
    assert auroc([(1,1),(1,0)])==0.5
    assert auroc([(1,1)]) is None


def test_analysis_rejects_ambiguous_duplicate_cases(tmp_path):
    path=tmp_path/'scores.csv';write_csv(path,[{'case':'a','score':1},{'case':'a','score':2}])
    with pytest.raises(ValueError,match='duplicate'):analyze(path,path)


def test_old_imports_use_single_canonical_scoring_function():
    from pdi_eval.robot_scoring import evaluate_object_metrics
    from pdi_eval.v1.pipeline import evaluate_object_metrics as compatibility
    assert compatibility is evaluate_object_metrics


def test_cli_records_exit_and_does_not_overwrite(tmp_path):
    record=tmp_path/'execution'
    command=[sys.executable,'-m','pdibench','run','--record',str(record),'links.run','--','--help']
    done=subprocess.run(command,cwd=root(),capture_output=True,text=True)
    assert done.returncode==0,done.stderr
    payload=json.loads((record/'execution.json').read_text())
    assert payload['status']=='complete' and payload['exit_code']==0
    again=subprocess.run(command,cwd=root(),capture_output=True,text=True)
    assert again.returncode!=0
    assert json.loads((record/'execution.json').read_text())==payload


def test_all_source_aliases_resolve_to_their_owner():
    for row in manifest()['files']:
        assert (root()/row['compat']).is_symlink(),row
        assert (root()/row['compat']).resolve()==(root()/row['new']).resolve(),row
