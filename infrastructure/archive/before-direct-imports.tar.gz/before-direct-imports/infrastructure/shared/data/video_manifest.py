#!/usr/bin/env python3
"""Build a deterministic, dataset-qualified manifest for remote video staging."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def job_slug(dataset: str, relative_path: str, sha256: str) -> str:
    stem = str(Path(relative_path).with_suffix(""))
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", f"{dataset}_{stem}").strip("_.-")
    return f"{slug}-{sha256[:12]}"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", action="append", required=True, metavar="NAME=DIR")
    parser.add_argument(
        "--replays-per-dataset",
        type=int,
        default=0,
        help="Mark the first N sorted videos in each dataset for replay rendering",
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.replays_per_dataset < 0:
        parser.error("--replays-per-dataset must be non-negative")

    datasets: dict[str, dict[str, dict[str, object]]] = {}
    for specification in args.dataset:
        if "=" not in specification:
            parser.error(f"invalid dataset specification: {specification!r}")
        dataset, root_value = specification.split("=", 1)
        root = Path(root_value).resolve()
        if not root.is_dir():
            parser.error(f"dataset directory is missing: {root}")
        videos = sorted(root.rglob("*.mp4"))
        dataset_records = datasets.setdefault(dataset, {})
        for video in videos:
            relative_path = video.relative_to(root).as_posix()
            digest = sha256_file(video)
            record = {
                "dataset": dataset,
                "relative_path": relative_path,
                "staged_relative_path": f"{dataset}/{relative_path}",
                "job_id": job_slug(dataset, relative_path, digest),
                "sha256": digest,
                "size_bytes": video.stat().st_size,
            }
            existing = dataset_records.get(relative_path)
            if existing is not None:
                if (
                    existing["sha256"] != record["sha256"]
                    or existing["size_bytes"] != record["size_bytes"]
                ):
                    raise RuntimeError(
                        f"conflicting duplicate video for {dataset}/{relative_path}"
                    )
                continue
            dataset_records[relative_path] = record

    records = []
    for dataset, dataset_records in datasets.items():
        if args.replays_per_dataset > len(dataset_records):
            parser.error(
                f"dataset {dataset!r} has only {len(dataset_records)} videos, "
                f"fewer than the requested {args.replays_per_dataset} replays"
            )
        for dataset_index, relative_path in enumerate(sorted(dataset_records)):
            record = dict(dataset_records[relative_path])
            record["replay_selected"] = dataset_index < args.replays_per_dataset
            records.append(record)
    job_ids = [record["job_id"] for record in records]
    if len(job_ids) != len(set(job_ids)):
        raise RuntimeError("dataset-qualified job IDs are not unique")
    payload = {
        "schema_version": 2,
        "video_count": len(records),
        "total_size_bytes": sum(record["size_bytes"] for record in records),
        "replay_count": sum(record["replay_selected"] for record in records),
        "replays_per_dataset": args.replays_per_dataset,
        "videos": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_suffix(".tmp.json")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")
    temporary.replace(args.output)
    print(json.dumps({"videos": len(records), "output": str(args.output.resolve())}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
