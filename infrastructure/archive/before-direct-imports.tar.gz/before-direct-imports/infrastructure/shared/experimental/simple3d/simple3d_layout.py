"""One result root per Simple3D run, with legacy paths retained as provenance."""

# Source ownership changed; retain historical resource/provenance paths.
from pathlib import Path as _LayoutPath
_SOURCE_PATH = _LayoutPath(__file__).absolute()
for _layout_root in _SOURCE_PATH.resolve().parents:
    if (_layout_root / "documentation/architecture/layout.json").is_file():
        _SOURCE_PATH = _layout_root / 'infrastructure/compat' / 'experiments/simple3d_layout.py'
        import sys as _layout_sys
        _layout_sys.path[:0] = [str(_layout_root / "infrastructure/compat" / "scripts"), str(_layout_root / "infrastructure/compat"), str(_layout_root / "infrastructure/compat" / "PDI-Bench-edited/src"), str(_layout_root / "infrastructure/compat" / "PDI-Bench-edited")]
        break

from pathlib import Path

ROOT = _SOURCE_PATH.parents[1]
FOLDERS = {"object": "object", "cad": "link5_cad", "first_frame": "link5_first_frame",
           "inputs": "inputs", "metadata": "metadata", "correlation": "correlation", "replay": "replay"}
LEGACY_PREFIXES = {"object": "simple3d-object-deformation", "cad": "simple3d-link5-cad-reference",
                   "first_frame": "simple3d-link5-firstframe-reference", "inputs": "simple3d-inputs",
                   "metadata": "simple3d-run"}


def run_root(run_id, output_root=None):
    return Path(output_root or ROOT / "results") / f"simple3d-{run_id}"


def result_path(run_id, role, output_root=None, *, existing=False):
    parent = Path(output_root or ROOT / "results")
    canonical = run_root(run_id, parent) / FOLDERS[role]
    if existing and not canonical.exists() and role in LEGACY_PREFIXES:
        legacy = parent / f"{LEGACY_PREFIXES[role]}-{run_id}"
        if legacy.exists():
            return legacy
    return canonical


def resolve_recorded_path(path, run_id, output_root=None):
    """Resolve historical GPU/Mac result paths without changing original records."""
    original = Path(path)
    if original.exists():
        return original
    parent = Path(output_root or ROOT / "results")
    text = str(path)
    if "/results/" in text:
        relative = text.split("/results/", 1)[1]
    elif text.startswith("results/"):
        relative = text[len("results/"):]
    else:
        return original
    for role, prefix in LEGACY_PREFIXES.items():
        name = f"{prefix}-{run_id}"
        if relative == name or relative.startswith(name + "/"):
            tail = relative[len(name):].lstrip("/")
            return result_path(run_id, role, parent, existing=True) / tail
    return parent / relative
