"""Repository locations and compatibility-aware source staging."""
from pathlib import Path
import json
import os


def root():
    for parent in Path(__file__).resolve().parents:
        if (parent / 'documentation/architecture/layout.json').is_file():
            return parent
    raise RuntimeError('Use pdibench from the source checkout or an editable install')


def manifest():
    return json.loads((root() / 'documentation/architecture/layout.json').read_text())


def environment():
    repo = root()
    compat = repo / 'infrastructure/compat'
    env = os.environ.copy()
    paths = [repo, compat, compat / 'PDI-Bench-edited/src', compat / 'PDI-Bench-edited', compat / 'scripts']
    env['PYTHONPATH'] = os.pathsep.join([*(str(p) for p in paths), env.get('PYTHONPATH', '')])
    return env


def interfaces():
    return json.loads((root() / 'documentation/architecture/interfaces.json').read_text())
